fetch("data/quiz.json")
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById("quiz-container");
    data.questions.forEach((q, idx) => {
      const div = document.createElement("div");
      div.innerHTML = `<p>${q.question}</p>` + q.options.map(opt => `<label><input type="radio" name="q${idx}" value="${opt}"> ${opt}</label>`).join("<br>");
      container.appendChild(div);
    });
  });
