const urlParams = new URLSearchParams(window.location.search);
const title = urlParams.get("title");
document.getElementById("title").textContent = title;

fetch("data/stories.json")
  .then(res => res.json())
  .then(data => {
    const story = data.stories.find(s => s.title === title);
    const container = document.getElementById("story-container");
    let text = story.text;
    container.textContent = text;
    speakText(text, container);
  });

let currentUtterance;
function speakText(text, container) {
  currentUtterance = new SpeechSynthesisUtterance(text);
  currentUtterance.lang = "id-ID";
  currentUtterance.onboundary = (event) => {
    const word = text.substring(event.charIndex).split(' ')[0];
    container.innerHTML = text.replace(word, `<mark>${word}</mark>`);
  };
  speechSynthesis.speak(currentUtterance);
}
function toggleSpeech() {
  if (speechSynthesis.speaking) {
    if (speechSynthesis.paused) {
      speechSynthesis.resume();
    } else {
      speechSynthesis.pause();
    }
  }
}
